<script src="https://demos.jquerymobile.com/1.4.2/js/jquery.mobile-1.4.2.min.js"></script>
<link href="https://vjs.zencdn.net/7.11.4/video-js.css" rel="stylesheet" />
            <div class="page-breadcrumb bg-white">
                <div class="row align-items-center">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Step 4 - Add Texts </h4>
                    </div>
                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                        <div class="d-md-flex">
                            <ol class="breadcrumb ms-auto">
                                <li><a href="#" class="fw-normal">Dashboard</a></li>
                            </ol>
                           
                        </div>
                    </div>
                </div>
                
            </div>
            <div class="container-fluid">


                <style type="text/css">
                    
                </style>
                <div class="row">
                    <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                        <div class="white-box">
                            <?php $vid=$this->db->where('user_id',$_SESSION['user']['id'])->get('merge_videos')->result_array(); 
                            if(count($vid)<1){
                                 $_SESSION['step']=1;
                                 header('location:'.base_url('home'));
                            }?>
                            <center>
                                <video
    id="my-video"
    class="video-js"
    controls
    preload="auto"
    width="640"
    height="264"
    poster=""
    data-setup="{}"
  >
  <source src="<?php echo base_url().'uploads/videos/'.$vid[0]['url'] ?>" type="video/mp4" />
</video>
                            </center>
                            
                            <form id="trim_video_submit" onsubmit="return render_video()">
                                <div class="form-group">
                                 <label>Add Text</label>
                                 <input type="text" name="text" class="form-control" required placeholder="Teg:This is my first video">
                                </div>
                                <div class="form-group">
                                 <label>Font Size in px</label>
                                 <input type="number" name="font_size" class="form-control"  value="18" required placeholder="eg:18">
                                </div>
                                <div class="form-group">
                                 <label>Font Color</label>
                                 <input type="color" name="font_color" class="form-control" required placeholder="skyblue">
                                </div>
                                <div class="form-group">
                                 <label>Text Position</label>
                                 <select class="form-control" name="position">
                                     <option value="top_left">Top Left</option>
                                     <option value="top_center">Top Center</option>
                                     <option value="top_right">Top Right</option>
                                     <option value="center">Center</option>
                                     <option value="left_bottom">Bottom Left</option>
                                     <option value="bottom_center">Bottom Center</option>
                                     <option value="right_bottom">Bottom Right</option>
                                 </select>
                                </div>

                                <div id="from-error" style="margin:5px;">
                                </div>
                                <button style="color: #fff!important;
    text-shadow: 0 1px 0 #f3f3f3;
    width: 20%;" type="submit" id="fwxm" class="btn btn-success">
                                    Submit
                                </button>
                            </form>

                </div>
                <!-- ============================================================== -->
                <!-- RECENT SALES -->
                <!-- ============================================================== -->
                
                    <!-- /.col -->
                </div>
            </div>
            <script>
                function render_video(){
                    $('.preloader').show();
                    $('#fwxm').html('<i class="fas fa-spinner fa-pulse"></i>');
                    var form=jQuery("#trim_video_submit")[0];
                    var formdata1=new FormData(form);
                    jQuery.ajax({
                      url:'<?php echo base_url('home/manage_render_video') ?>',
                      type:'post',
                      data:formdata1,
                      contentType: false, // NEEDED, DON'T OMIT THIS (requires jQuery 1.6+)
                      processData: false,
                      success:function(result){
                        $('.preloader').hide();
                        $('#fwxm').text('Submit');
                        var obj=JSON.parse(result);
                      if(obj.status==1){
                        jQuery(form).trigger("reset");
                        window.location.href="";
                      }else{
                       $('#from-error').html('<p style="color:red">'+obj.err+'</p>'); 
                      }
                     },
                     fail: function(xhr, textStatus, errorThrown){
                      alert('Something went wrong! Please Try Again Later');
                      $('.preloader').show();
                     }
                  });
                    return false;
                }
            </script>
            <script src="https://vjs.zencdn.net/7.11.4/video.min.js"></script>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
            