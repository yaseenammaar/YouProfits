import pytube,sys 
from pytube import YouTube
from pytube.cli import on_progress
video_id = sys.argv[1]; 
video_name = sys.argv[2];
video_url = 'https://www.youtube.com/watch?v='+video_id 
youtube = pytube.YouTube(video_url) 
video = youtube.streams.get_highest_resolution()
video.download('/var/www/html/video_editor_3/uploads/videos/',filename=video_name) 
print('true')
